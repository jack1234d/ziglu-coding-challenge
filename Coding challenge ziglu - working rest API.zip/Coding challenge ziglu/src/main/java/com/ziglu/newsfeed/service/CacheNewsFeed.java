package com.ziglu.newsfeed.service;

import com.ziglu.newsfeed.config.NewsProviderConfig;
import com.ziglu.newsfeed.loader.FeedLoadable;
import com.ziglu.newsfeed.loader.RssDownloader;
import com.ziglu.newsfeed.models.Article;
import com.ziglu.newsfeed.models.InputFeed;
import com.ziglu.newsfeed.models.NewsProvider;
import com.ziglu.newsfeed.persistence.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class CacheNewsFeed {

    private NewsProviderConfig config;
    private Cache cache;

    @Autowired
    public CacheNewsFeed(NewsProviderConfig config) {
        this.config = config;
        this.cache = Cache.getCache();
    }

    @Scheduled(fixedDelay = 60000)
    public void reloadCache() {
        try {
            loadForAllNewsProviders();
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    @PostConstruct
    public void loadForAllNewsProviders() {
        List<Article> newArticleList = new ArrayList<>();
        List<String> providers = new ArrayList<>();
        FeedLoadable importer = RssDownloader.createRssLoader();
        NewsProvider[] providerArray = config.getProviders();
        Arrays.stream(providerArray).forEach((provider) -> {
            InputFeed feed = importer.loadFeed(provider);
            newArticleList.addAll(Arrays.asList(feed.getArticles()));
            providers.add(provider.getName());
        });
        cache.setArticleList(sortArticlesByPublicationDate(newArticleList));
        cache.setCategories(getCategories(newArticleList));
        cache.setFeedProviders(providers);
    }

    private List<Article> sortArticlesByPublicationDate(List<Article> articles) {
        return articles.stream()
                .sorted(Comparator.comparing(Article::getPublicationDate))
                .collect(Collectors.toList());
    }

    private Set<String> getCategories(List<Article> newArticleList) {
        return newArticleList
            .stream()
            .flatMap(article -> {
                if (null == article.getCategories()) {
                    System.out.println("No categories");
                    return Stream.empty();
                } else {
                    if (article.getCategories().length > 1) {
                        System.out.println("More than one category");
                    }
                    return Arrays.stream(article.getCategories());
                }
            })
            .collect(Collectors.toSet());
    }

}
