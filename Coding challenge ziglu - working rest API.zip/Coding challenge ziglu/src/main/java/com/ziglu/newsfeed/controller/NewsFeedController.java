package com.ziglu.newsfeed.controller;

import com.ziglu.newsfeed.models.Article;
import com.ziglu.newsfeed.models.NewsFeed;
import com.ziglu.newsfeed.service.RetrieveFeedService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@RestController
public class NewsFeedController {

    private RetrieveFeedService service;

    public NewsFeedController(RetrieveFeedService service) {
        this.service = service;
    }

    @RequestMapping(
            value = "/newsfeed",
            method = GET,
            produces = "application/json")
    public NewsFeed getNewsFeed(
            @RequestParam(value="category", required = false) String[] filterCategories,
            @RequestParam(value="provider", required = false) String[] filterProviders) {
        return service.getNewsFeed(filterCategories, filterProviders);
    }

    @RequestMapping(
            value = "/articles",
            method = GET,
            produces = "application/json")
    public List<Article> getFilteredArticles(
            @RequestParam(value="category", required = false) String[] filterCategories,
            @RequestParam(value="provider", required = false) String[] filterProviders) {
        return service.getFilteredArticles(filterCategories, filterProviders);
    }

    @RequestMapping(
            value = "/categories",
            method = GET,
            produces = "application/json")
    public Set<String> getCategories() {
        return service.getCategories();
    }

    @RequestMapping(
            value = "/providers",
            method = GET,
            produces = "application/json")
    public List<String> getProviders() {
        return service.getProviders();
    }
}
