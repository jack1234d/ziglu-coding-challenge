package com.ziglu.newsfeed.service;

import com.ziglu.newsfeed.models.Article;
import com.ziglu.newsfeed.models.NewsFeed;
import com.ziglu.newsfeed.models.NewsFeedBuilder;
import com.ziglu.newsfeed.persistence.Cache;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class RetrieveFeedService {

    public NewsFeed getNewsFeed(String[] filterCategories, String[] filterProviders) {
        return NewsFeedBuilder.aNewsFeed()
                .withArticles(getFilteredArticles(filterCategories, filterProviders))
                .withCategories(Cache.getCategories())
                .withProviders(Cache.getFeedProviders())
                .build();
    }

    public List<Article> getFilteredArticles(String[] filterCategories, String[] filterProviders) {
        Stream<Article> cachedArticlesStream = Cache.getArticles().stream();
        Supplier<Stream<String>> filterProviderStreamSupplier = () -> Stream.of(filterProviders);
        if (isFilterActive(filterCategories)) {
            System.out.println("Filter categories active");
            cachedArticlesStream = cachedArticlesStream.filter(article ->
                    Arrays.stream(article.getCategories())
                            .anyMatch(Arrays.asList(filterCategories)::contains));
        }
        if (isFilterActive(filterProviders)) {
            System.out.println("Filter providers active");
            cachedArticlesStream = cachedArticlesStream.filter(article ->
                    filterProviderStreamSupplier.get().anyMatch(article.getProvider()::contains));
        }
        return cachedArticlesStream.collect(Collectors.toList());
    }

    public Set<String> getCategories() {
        return Cache.getCategories();
    }

    public List<String> getProviders() {
        return Cache.getFeedProviders();
    }

    private boolean isFilterActive(String[] filterArray) { return filterArray != null && filterArray.length > 0; }


}
