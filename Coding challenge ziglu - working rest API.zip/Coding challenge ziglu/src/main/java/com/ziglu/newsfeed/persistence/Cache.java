package com.ziglu.newsfeed.persistence;

import com.ziglu.newsfeed.models.Article;

import java.util.List;
import java.util.Set;

public class Cache {
    private static List<Article> articleList;
    private static List<String> feedProviders;
    private static Set<String> categories;
    private static Cache singleInstance;

    public static Cache getCache()
    {
        if (singleInstance == null)
            singleInstance = new Cache();

        return singleInstance;
    }

    private Cache() {
    }

    public static List<Article> getArticles() {
        return articleList;
    }

    public static List<String> getFeedProviders() {
        return feedProviders;
    }

    public static Set<String> getCategories() {
        return categories;
    }

    public void setArticleList(final List<Article> articleList) {
        this.articleList = articleList;
    }

    public void setFeedProviders(final List<String> feedProviders) {
        this.feedProviders = feedProviders;
    }

    public void setCategories(final Set<String> categories) {
        this.categories = categories;
    }
}
