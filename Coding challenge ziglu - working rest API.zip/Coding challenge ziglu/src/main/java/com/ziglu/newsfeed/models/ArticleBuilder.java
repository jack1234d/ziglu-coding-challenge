package com.ziglu.newsfeed.models;

import java.util.Date;

public final class ArticleBuilder {
    private String url;
    private String summary;
    private String[] categories;
    private String html;
    private String thumbnail;
    private Date publicationDate;
    private String provider;

    private ArticleBuilder() {
    }

    public static ArticleBuilder anArticle() {
        return new ArticleBuilder();
    }

    public ArticleBuilder withUrl(String url) {
        this.url = url;
        return this;
    }

    public ArticleBuilder withCategories(String[] categories) {
        this.categories = categories;
        return this;
    }

    public ArticleBuilder withHtml(String html) {
        this.html = html;
        return this;
    }

    public ArticleBuilder withThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
        return this;
    }

    public ArticleBuilder withPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
        return this;
    }

    public ArticleBuilder withSummary(String summary) {
        this.summary = summary;
        return this;
    }

    public ArticleBuilder withProvider(String provider) {
        this.provider = provider;
        return this;
    }

    public Article build() {
        Article article = new Article();
        article.setUrl(url);
        article.setCategories(categories);
        article.setHtml(html);
        article.setThumbnail(thumbnail);
        article.setPublicationDate(publicationDate);
        article.setSummary(summary);
        article.setProvider(provider);
        return article;
    }
}
