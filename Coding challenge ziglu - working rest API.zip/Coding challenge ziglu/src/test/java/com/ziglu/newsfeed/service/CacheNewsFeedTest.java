package com.ziglu.newsfeed.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ziglu.newsfeed.config.NewsProviderConfig;
import com.ziglu.newsfeed.models.NewsFeed;
import com.ziglu.newsfeed.models.NewsFeedBuilder;
import com.ziglu.newsfeed.models.NewsProvider;
import com.ziglu.newsfeed.persistence.Cache;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
class CacheNewsFeedTest {

    @InjectMocks
    private CacheNewsFeed sut;

    @Mock
    private NewsProviderConfig config;

    public void setUp(){
        config = mock(NewsProviderConfig.class);
        sut = new CacheNewsFeed(config);
    }

    @Test
    void loadForAllNewsProviders() throws JsonProcessingException {
        setUp();
        NewsProvider[] providers = generateNewsProvider();
        when(config.getProviders()).thenReturn(providers);
        sut = new CacheNewsFeed(config);
        sut.loadForAllNewsProviders();

        ObjectMapper mapper = new ObjectMapper();
        NewsFeed feed = NewsFeedBuilder.aNewsFeed()
                .withArticles(Cache.getArticles())
                .withProviders(Cache.getFeedProviders())
                .withCategories(Cache.getCategories())
                .build();

        System.out.println(mapper.writeValueAsString(feed));
    }

    private NewsProvider[] generateNewsProvider() {
        ArrayList<NewsProvider> list = new ArrayList<>();
        list.add(new NewsProvider("BBC", "http://feeds.bbci.co.uk/news/uk/rss.xml"));
        list.add(new NewsProvider("BBC News Technology", "http://feeds.bbci.co.uk/news/technology/rss.xml"));
        list.add(new NewsProvider("Reuters UK", "http://feeds.reuters.com/reuters/UKdomesticNews?format=xml"));
        list.add(new NewsProvider("Reuters Technology", "http://feeds.reuters.com/reuters/technologyNews?format=xml"));
        return list.toArray(new NewsProvider[list.size()]);
    }
}